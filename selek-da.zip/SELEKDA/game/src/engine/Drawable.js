class Drawable {
  constructor({ ctx }) {
    this.ctx = ctx;
  }
  draw() {}
}

export default Drawable;
